#pragma once

#include <set>

#include "Core/Types.hpp"


class System
{
public:
	std::set<Entity> mEntities;
};

